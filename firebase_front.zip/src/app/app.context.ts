﻿import { Inject, Injectable, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/toPromise';
import { isUndefined } from 'util';

import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';

import { AppDataCtx }   from './app.data.context';

import {IPropertyChangedEvent, IAuthChangedEvent} from './model';

@Injectable()
export class AppCtx {

private config: Object = undefined;
private env: Object = undefined;
private dataCtx: AppDataCtx = undefined;
private userCtx: Object = undefined;
private propertyChangedEvent: EventEmitter<IPropertyChangedEvent> = new EventEmitter();
public authChangedEvent: EventEmitter<IAuthChangedEvent> = new EventEmitter();
private currentUser: firebase.User = null;
private currentUserCallback: Subscription;

constructor(private http: Http, private firebaseAuth: AngularFireAuth) {
        this.dataCtx = new AppDataCtx();
        this.currentUserCallback = firebaseAuth.authState.subscribe((user) => {
            this.manageAuthChange(user);
        });
    }

public manageAuthChange(user: firebase.User): void {
    console.log('Authorization context changed: fireing event...');
    this.fireAuthEvent(user, null, null);
}

public fireAuthEvent( u: firebase.User, oVal: any, nVal: any) :void {
    this.authChangedEvent.emit({ user: u, oldVal: oVal, newVal: nVal});
}

public OnProperyChanged(property: string, nVal: any, oVal?: any): void {
    this.propertyChangedEvent.emit({name: property, oldVal: oVal, newVal: nVal});
}

public getDataCtx(): AppDataCtx {
    return this.dataCtx;
}

public signup(email: string, password: string): Promise<firebase.User> {
    return this.firebaseAuth
    .auth
    .createUserWithEmailAndPassword(email, password)
    .then((value:firebase.auth.UserCredential) => {
        this.currentUser = value.user;
        this.fireAuthEvent(this.currentUser, null, null);
        console.log('Success!', value);
        return value.user;
    }).catch(err => {
        console.log('Something went wrong:', err.message);
        return null;
    });    
}
    
public login(email: string, password: string): Promise<firebase.User> {
    return this.firebaseAuth
    .auth
    .signInWithEmailAndPassword(email, password)
    .then((value:firebase.auth.UserCredential) => {
        this.currentUser = value.user;
        this.fireAuthEvent(this.currentUser, null, value.user.uid);
         console.log(value);
         return value.user;
    }).catch(err => {
        console.log('Something went wrong:',err.message);
        return null;
    });
}
    
public logout(): Promise<any> {
    return this.firebaseAuth
    .auth
    .signOut();
}

    /**
     * User Context proprietà relative al utente collegato
     */
    public setLogged(user: firebase.User, accessToken: string, fire: boolean = true): void {
    /*    this.setCurrentUser(user);
        localStorage.setItem('utente', JSON.stringify(user));
        this.setAccessToken(accessToken);
        localStorage.setItem('accessToken', accessToken);
        if (fire) {
            this.OnProperyChanged('logged', user);
        }*/
    }
    public isLogged(): boolean {
        if (isUndefined(this.userCtx)) {
        return false; }
        return <boolean>this.userCtx['isLogged'];
    }

    public getCurrentUser(): firebase.User {
        return this.currentUser;
    }

    public getAccessToken(): string {
        if (isUndefined(this.userCtx)) { return undefined; }
        return <string>this.userCtx['accessToken'];
    }

    public getRefreshToken(): string {
        if (isUndefined(this.userCtx)) { return undefined; }
        return <string>this.userCtx['refreshToken'];
    }
    public setRefreshToken(token: string): void {
        this.userCtx['refreshToken'] = token;
    }

    /**
     * Use to get the data found in the second file (config file)
     */
    public getConfig(key: any) {  return this.config[key]; }
	public setConfig(key: string, value: any) {
		this.config[key] = value;
	}
    /**
     * Use to get the data found in the first file (env file)
     */
    public getEnv(key: any): any {  return this.env[key]; }
    /**
     * This method:
     *   a) Loads "env.json" to get the current working environment (e.g.: 'production', 'development')
     *   b) Loads "config.[env].json" to get all env's variables (e.g.: 'config.development.json')
     */
    public load() {
         console.log('Configuration loading file...');
        return new Promise((resolve, reject) => {
            this.http.get('./assets/config/env.json').map(res => res.json()).catch((error: any): any => {
                console.log('Configuration file "env.json" could not be read');
                resolve(true);
                return Observable.throw(error.json().error || 'Server error');
            }).subscribe((envResponse) => {
                this.env = envResponse;
                let request: any = null;

                switch (envResponse.env) {
                    case 'production': {
                        request = this.http.get('./assets/config/config.' + envResponse.env + '.json');
                    } break;

                    case 'development': {
                        request = this.http.get('./assets/config/config.' + envResponse.env + '.json');
                    } break;

                    case 'default': {
                        console.error('Environment file is not set or invalid');
                        resolve(true);
                    } break;
                }

                if (request) {
                    request
                        .map(res => res.json())
                        .catch((error: any) => {
                            console.error('Error reading ' + envResponse.env + ' configuration file');
                            resolve(error);
                            return Observable.throw(error.json().error || 'Server error');
                        })
                        .subscribe((responseData) => {
                            this.config = responseData;
                            resolve(true);
                        });
                } else {
                    console.error('Env config file "env.json" is not valid');
                    resolve(true);
                }
            });

        }).then(()=>{
            //dopo caricata la configurazione
            this.dataCtx.initFromConfig(this.config);
        }).then(()=> {
/*
            let at=localStorage.getItem('accessToken');
            if (at!== undefined) {
                this.setAccessToken(at);
            }
            let strUser: string = localStorage.getItem('utente');
            if(u!==undefined) {
                let u:AnacUser = JSON.parse(strUser);
                this.setCurrentUser(u);
                if (at!== undefined) {}
                this.setLogged(u, at, false);
                console.log('loaded USER');
            }*/
        });
    }
}