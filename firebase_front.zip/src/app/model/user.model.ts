import { Data } from "@angular/router";

export class Address {
    via: string;
    cap: string;
    citta: string;
    regione: string;
    nazione: string;
    constructor() {
        this.via = '';
        this.cap = '';
        this.citta = '';
        this.regione = '';
        this.nazione = '';
}
}
export class RappresentanteLegale {
    cf: string;
    codSoggettoCon: string;
    codSoggettoPar: string;
    codiceNazioneNascita: string;
    comuneNascita: string;
    comuneNascitaEstero: string;
    dataNascita: Date;
    nome: string;
    cognome: string;
    pec: string;
    email: string;
    tel: string;
    titolo: string;
    constructor() {
        this.cf = '';
        this.codSoggettoCon = '';
        this.codSoggettoPar = '';
        this.codiceNazioneNascita = '';
        this.comuneNascita = '';
        this.comuneNascitaEstero = '';
        this.nome = '';
        this.cognome = '';
        this.pec = '';
        this.email = '';
        this.tel = '';
        this.titolo = '';
}
}

export class Amministrazione {
    cf: string;
    denominazione: string;
    indirizzo: string;
    pec: string;
    constructor() {
        this.cf = '';
        this.denominazione = '';
        this.indirizzo = '';
        this.pec = '';
}
}

export class AnacUser {
    username: string;
    password: string;
    rappresentanteLegale: RappresentanteLegale;
    amministrazioniList: Amministrazione[];
    constructor() {
        this.username = '';
        this.password = '';
        this.rappresentanteLegale = new RappresentanteLegale();
        this.amministrazioniList = [];
}

setRappresentanteLegaleFromSoggetto(rappresentante): void {
    let rap = rappresentante['rappresentanteLegale']
    let residenza = rap['residenza'];
    let contatti = residenza['contattiDTO'];
    let soggetto = rap['soggetto'];
    let rapp: RappresentanteLegale = new RappresentanteLegale();
    rapp.cf = soggetto['codiceFiscale'];
    rapp.codSoggettoCon = soggetto['codSoggettoCon'];
    rapp.codSoggettoPar = soggetto['codSoggettoPar'];
    rapp.codiceNazioneNascita =  soggetto['codiceNazioneNascita'];
    rapp.comuneNascita = soggetto['comuneNascita'];
    rapp.comuneNascitaEstero = (soggetto['comuneNascitaEstero'] === undefined) ? soggetto['codiceNazioneNascita'] : soggetto['comuneNascitaEstero'];
    rapp.dataNascita = soggetto['dataNascita'];
    rapp.nome = soggetto['nome'];
    rapp.cognome = soggetto['cognome'];
    rapp.pec = contatti['pec'];
    rapp.email = contatti['email'];
    rapp.tel = contatti['telefono'];
    this.rappresentanteLegale = rapp;
}

}
