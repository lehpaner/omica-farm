export { DocsModule } from './docs.module';
