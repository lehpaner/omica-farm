import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { adminRoutes } from './admin.routes';

import { AdminComponent } from './admin.component';
import { NodeListComponent, NodeComponent, NodeViewComponent, NodeEditComponent, NodeListViewComponent} from './nodes'

import { AdminDocsComponent } from './admindoc/doc-manage.component';
import { AdminDocComponent } from './admindoc/doc-edit.component';
import { ListaUtentiComponent } from './users/utenti.component';
import { UserFormComponent } from './users/utente-edit.component';
import { AdminGestioneComponent } from './admingestione/admingestione.component';

import { UserService } from './services/admin.user.service';
import { AdminDocsService } from './services/admin.docs.service';

import { DocumentationToolsModule } from '../common/documentation-tools';
import { SharedModule } from '../shared/shared.module';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { CovalentHighlightModule } from '@covalent/highlight';
import { CovalentMarkdownModule } from '@covalent/markdown';
import { CovalentDynamicFormsModule } from '@covalent/dynamic-forms';
import { CovalentTextEditorModule } from '@covalent/text-editor';
import { ToolbarModule } from '../common/toolbar/toolbar.module';

@NgModule({
  declarations: [
      AdminComponent,
      AdminDocsComponent,
      ListaUtentiComponent,
      AdminGestioneComponent,
      AdminDocComponent,
      UserFormComponent,
      NodeListComponent,
      NodeComponent,
      NodeViewComponent,
      NodeEditComponent,
      NodeListViewComponent
  ],
  imports: [
    /** Angular Modules */
    CommonModule,
    SharedModule,
    DocumentationToolsModule,
    MatDatepickerModule,
    CovalentHighlightModule,
    CovalentMarkdownModule,
    CovalentTextEditorModule,
    CovalentDynamicFormsModule,
    adminRoutes,
    ToolbarModule,
  ],
  providers: [
    UserService,
    AdminDocsService,
  ],
})
export class AdminModule {}
