import { Routes, RouterModule } from '@angular/router';

import { AdminComponent } from './admin.component';
import { NodeListComponent } from './nodes/nodes.component';
import { NodeComponent } from './nodes/node.component';
import { AdminDocsComponent } from './admindoc/doc-manage.component';
import { AdminDocComponent } from './admindoc/doc-edit.component';
import { ListaUtentiComponent } from './users/utenti.component';
import { UserFormComponent } from './users/utente-edit.component';
import { AdminGestioneComponent } from './admingestione/admingestione.component';

const routes: Routes = [{
  children: [{
    component: NodeListComponent,
    path: '',
    }, {
      component: NodeComponent,
      path: 'node/:id',
    }, {
      component: ListaUtentiComponent,
      path: 'users',
    }, {
      component: UserFormComponent,
      path: 'user/:id',
    }, {
      component: AdminDocsComponent,
      path: 'docs',
    }, {
      component: AdminDocComponent,
      path: 'doc',
    }, {
      component: AdminGestioneComponent,
      path: 'forms',
    },
  ],
  component: AdminComponent,
  path: 'admin',
}];
export const adminRoutes: any = RouterModule.forChild(routes);
