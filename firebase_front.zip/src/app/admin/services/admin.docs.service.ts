﻿import { Injectable, Sanitizer, SecurityContext } from '@angular/core';
import { Response } from '@angular/http';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { catchError } from 'rxjs/operators/catchError';

import { IDocument } from '../model/document.model';
import { AppCtx }       from '../../app.context';
import { DOPI }       from '../../dopi';

@Injectable()
export class AdminDocsService {
    docLocation: string;
    constructor(private _http: HttpClient, private _ctx: AppCtx, 
        private _sanitizer: Sanitizer, private _dopi: DOPI) {

    }

    getDocList(): Observable<IDocument[]>
    {
        return this._http.get(this._sanitizer.sanitize(SecurityContext.URL, './assets/guida/toc.json'), { responseType: 'text' })
            .map((res: string) => {
                console.log(res);
                return JSON.parse(res);
            });
    }

    getDoc(resourceUrl: string): Observable<string> {
        let url= this._sanitizer.sanitize(SecurityContext.URL, './assets/guida/' + resourceUrl);
       return this._http.get(url, {responseType: 'text'}).map((res: string) => {
                console.log(res);
                return res;
            });
    }
/*
    uploadText(fileName: string, folder: string, text: string ): Observable<any> {
        return this._dopi.uploadText(fileName, folder, text).then((result) => {
            console.log(result);
                return result;
        });
    }*/
}