import { Component, OnInit, ViewChild, HostBinding } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { TdLoadingService } from '@covalent/core/loading';
import { TdDialogService } from '@covalent/core/dialogs';

import { AdminDocsService } from '../services/admin.docs.service';
import {  IDocument } from '../model/document.model';
import { slideInDownAnimation } from '../../app.animations';
import { TdTextEditorComponent } from '@covalent/text-editor';
import { AppCtx } from '../../app.context';
import { DOPI } from '../../dopi';
import {  IResultRestModel} from '../../model';
import { IQNode, INodeWhere } from '../../nodes/model';
import 'rxjs/add/operator/toPromise';

@Component({
    selector: 'qs-doc-edit',
    styleUrls: ['./doc-edit.component.scss'],
    templateUrl: './doc-edit.component.html',
    animations: [slideInDownAnimation],
  })

  export class AdminDocComponent implements OnInit {

    id: string;
    docName: string;

    @ViewChild('editor') private _tdEditor: TdTextEditorComponent;
    @HostBinding('@routeAnimation') routeAnimation: boolean = true;
    @HostBinding('class.td-route-animation') classAnimation: boolean = true;

    constructor(private _docService: AdminDocsService,
        private _router: Router,
        private _route: ActivatedRoute,
        private _loadingService: TdLoadingService,
        private _ctx: AppCtx, private _dopi: DOPI,
        private _dialogService: TdDialogService) {}

goBack(): void {
this._router.navigate(['/admin/docs']);
}

ngOnInit(): void {

  this._route.queryParams.subscribe(qpar => {
    this.docName = qpar['docName'];
  });
  if(this.docName) {
    this.load(this.docName);
  }

}

async load(docName: string): Promise<void> {
try {
this._loadingService.register('doc.edit');
  this.editorVal = await this._docService.getDoc(docName).toPromise();
} catch (error) {
this._dialogService.openAlert({message: 'There was an error loading the user'});
} finally {
this._loadingService.resolve('doc.edit');
}
}

async save(): Promise<void> {
  let response:IResultRestModel;
  console.log('Saving document');
  try {
    response = await this._dopi.uploadText(this.docName, 'guide/', this.editorVal);
    console.log(response);
  }catch (error) {
    console.log('Error', error);
    this._dialogService.openAlert({message: 'There was an error uploading file'});
    } finally {
      console.log('Finlly risponde', response);
      console.log('Document saved');
}
}

editorVal: string = '';

}