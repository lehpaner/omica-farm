import { Component, AfterViewInit } from '@angular/core';

import { Title } from '@angular/platform-browser';

import { TdDigitsPipe } from '@covalent/core/common';
import { TdLoadingService } from '@covalent/core/loading';

import { AppCtx } from '../app.context';
import { DAPI } from '../dapi';
import { Node, IResultRestModel, IDapiChangedEvent, IAuthChangedEvent} from '../model';
import { IQNode, IDataRep} from '../nodes/model';

@Component({
  selector: 'qs-home-page',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements AfterViewInit {
  
  toolbarTitle: string = '';
  copyrightString: string = '';
  starCount: number = 0;

  sections: Object[] = [{
      color: 'deep-purple-A400',
      description: 'Guida utilizzo applicazione',
      icon: 'library_books',
      route: 'docs',
      title: 'Documentazione',
    }, {
      color: 'teal-A700',
      description: 'Consultazione albo commissari',
      icon: 'picture_in_picture',
      route: 'components',
      title: 'Consultazione dati',
    }, {
      color: 'cyan-A700',
      description: 'Inserimento dati',
      icon: 'view_quilt',
      route: 'layouts',
      title: 'Aggiornamento dati',
    },
  ];

  constructor(private _appCtx: AppCtx, private _dapi:DAPI) { 
    this.toolbarTitle = <string>_appCtx.getConfig('toolbarTitle');
    this.copyrightString = <string>_appCtx.getConfig('copyrightString');
  }
  ngAfterViewInit(): void {
  }
  
  addNode() {

  }
}
