# Consultazioni

La pagina di consultazione si presenta come sotto:

![Consultazione](./assets/guida/consultazione.jpg)



### Ricerca su tutti dati presenti

### Presentazione dati in tabella

### Paginazione dei risultati

### Applicazione dei filtri



 
