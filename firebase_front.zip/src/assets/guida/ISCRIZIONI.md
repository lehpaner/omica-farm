## Iscrizioni


![Iscrizioni](./assets/guida/iscrizioni.jpg)


![side_menu](./assets/guida/side_menu.jpg)


![step_1](./assets/guida/step_1.jpg)


![step_2](./assets/guida/step_2.jpg)


![step_3](./assets/guida/step_3.jpg)


![step_4](./assets/guida/step_4.jpg)


![step_5](./assets/guida/step_5.jpg)


![step_6](./assets/guida/step_6.jpg)